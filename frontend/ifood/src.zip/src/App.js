import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './pages/Home/components/Layout/Layout.jsx';
import Home from './pages/Home/Home.js';
import Fornecedor from './pages/Fornecedor/Fornecedor.js';

const App = () => {
  return (
    React.createElement(Router, null,
      React.createElement(Routes, null,
        React.createElement(Route, { path: "/", element: React.createElement(Layout) },
          React.createElement(Route, { index: true, element: React.createElement(Navigate, { to: "/fornecedor", replace: true }) }),
          React.createElement(Route, { path: "/fornecedor", element: React.createElement(Fornecedor) }),
          React.createElement(Route, { path: "/home", element: React.createElement(Home) })
        )
      )
    )
  );
};

export default App;
