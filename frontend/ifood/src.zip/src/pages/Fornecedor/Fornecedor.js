// pages/Fornecedor/Fornecedor.js
import React, { useState } from 'react';
import Menu from './components/Menu/Menu';
import Dashboard from './components/Dashboard/Dashboard';
import CadastroProdutos from './components/CadastroProdutos/CadastroProdutos';
import Relatorio from './components/Relatorio/Relatorio';
import TabelaVendas from './components/TabelaVendas/TabelaVendas';
import Loja from './components/Loja/Loja';
import './Fornecedor.css';

const Fornecedor = () => {
  const [activeScreen, setActiveScreen] = useState('home');

  const renderScreen = () => {
    switch(activeScreen) {
      case 'home':
        return React.createElement(Dashboard);
      case 'relatorio':
        return React.createElement(Relatorio);
      case 'vendas':
        return React.createElement(TabelaVendas);
      case 'produtos':
        return React.createElement(CadastroProdutos);
      case 'loja':
        return React.createElement(Loja);
      default:
        return React.createElement(Dashboard);
    }
  };

  return (
    React.createElement('div', { className: 'app-container' },
      React.createElement(Menu, {
        onNavigate: setActiveScreen,
        activeScreen: activeScreen
      }),
      React.createElement('main', { className: 'main-content' },
        renderScreen()
      )
    )
  );
};

export default Fornecedor;
