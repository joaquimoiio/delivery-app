// pages/Home/Home.js
import React from 'react';
import './Home.css';

const Home = () => {
  const restaurantItems = [1, 2, 3, 4, 5];

  return (
    React.createElement('div', { className: 'home-container' },
      React.createElement('section', { className: 'hero-section' },
        React.createElement('div', { className: 'hero-content' },
          React.createElement('h1', { className: 'hero-title' }, 'Praticidade que transforma sua rotina'),
          React.createElement('p', { className: 'hero-subtitle' }, 'Receba o que você precisa, onde quiser'),
          
          React.createElement('div', { className: 'search-container' },
            React.createElement('input', {
              type: 'text',
              placeholder: 'Buscar estabelecimentos...',
              className: 'search-input'
            }),
            React.createElement('button', { className: 'search-button' }, '🔍')
          ),

          React.createElement('div', { className: 'category-buttons' },
            React.createElement('button', { className: 'category-btn hamburgueria' }, 'Hamburgueria'),
            React.createElement('button', { className: 'category-btn comida-japonesa' }, 'Comida Japonesa')
          ),

          React.createElement('div', { className: 'action-buttons' },
            React.createElement('button', { className: 'action-btn bebidas' }, 'Bebidas'),
            React.createElement('button', { className: 'action-btn pizzas' }, 'Pizzas'),
            React.createElement('button', { className: 'action-btn acai' }, 'Açaí')
          )
        )
      ),

      React.createElement('section', { className: 'restaurants-section' },
        React.createElement('h2', { className: 'section-title' }, '🍔 Top Hamburgueria'),
        React.createElement('div', { className: 'restaurant-grid' },
          restaurantItems.map(item =>
            React.createElement('div', { key: item, className: 'restaurant-card' },
              React.createElement('div', { className: 'restaurant-image' })
            )
          )
        )
      ),

      React.createElement('section', { className: 'restaurants-section' },
        React.createElement('h2', { className: 'section-title' }, '🍱 Top Restaurante Japonês'),
        React.createElement('div', { className: 'restaurant-grid' },
          restaurantItems.map(item =>
            React.createElement('div', { key: item, className: 'restaurant-card' },
              React.createElement('div', { className: 'restaurant-image' })
            )
          )
        )
      )
    )
  );
};

export default Home;
