// components/Navbar/Navbar.jsx
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const navigate = useNavigate();

  const handleLoginClick = () => {
    navigate('/fornecedor');
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <div className="logo-placeholder"></div>
        </div>
        <ul className="navbar-menu">
          <li><Link to="/home" className="navbar-link">Hamburgueria</Link></li>
          <li><Link to="/fornecedor" className="navbar-link">Restaurante Japonês</Link></li>
          <li><Link to="/pizzas" className="navbar-link">Pizzas</Link></li>
        </ul>
        <button className="navbar-button" onClick={handleLoginClick}>
          Entrar
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
