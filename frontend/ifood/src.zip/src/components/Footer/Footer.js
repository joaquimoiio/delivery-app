// components/Footer/Footer.jsx
import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-brand">
          <div className="footer-logo"></div>
        </div>
        <div className="footer-content">
          <p>&copy; Copyright 2025 - Delivery todos os direitos reservados</p>
          <p>Criado pela Agência de Desenvolvimento QUALIFICA</p>
        </div>
        <div className="footer-links">
          <a href="/termos" className="footer-link">Termos e condições de uso</a>
          <a href="/privacidade" className="footer-link">Privacidade</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
